import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

//Compilation and Correct execution. - 10 MARKS

public class Main {

    public static String stripWord(String word) {
        return word.replaceAll("[^a-z]", "");
    }

    public static PositionList<IndexItem> lookup(String item, AVLTree<String, PositionList<IndexItem>> tree) {
        Entry<String, PositionList<IndexItem>> found = tree.find(item);
        if (found != null) {
            return found.getValue();
        }
        return null;
    }

    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Usage: " + args[0] + " <filename>");
        }

        //construct an AVL tree to act as an index
        AVLTree<String, PositionList<IndexItem>> indexTree = new AVLTree<>();

        try {
            Scanner sc = new Scanner(new File(args[0]));

            int lineNumber = 0;
            while (sc.hasNextLine()) {
                /** COMPLETE CODE HERE - 10 MARKS **/
                lineNumber++;
                String[] line = sc.nextLine().split(" ");
                int wordNumber = 0;
                for (String word: line) {
                    word = stripWord(word.toLowerCase());
                    wordNumber++;

                    //if we haven't everything
                    if (word != "") {
                        //get the word from the AVL tree
                        Entry<String, PositionList<IndexItem>> item = indexTree.find(word);
                        PositionList<IndexItem> index = null;
                        if (item == null) {
                            index = new NodePositionList<IndexItem>();
                            indexTree.insert(word, index);
                        } else {
                            index = item.getValue();
                        }

                        index.addLast(new IndexItem(wordNumber, lineNumber));
                    }
                }
            }

	    
        } catch (FileNotFoundException e) {
            System.out.println("Error: " + args[0] + " is not found");
        }

        System.out.println("There are " + indexTree.size() + " unique items in the index.");

        System.out.println("Looking up 'computer'");
        System.out.println("\t" + lookup("computer", indexTree));
        System.out.println("Looking up 'bob'");
        System.out.println("\t" + lookup("bob", indexTree));
        System.out.println("Looking up 'wikipedia'");
        System.out.println("\t" + lookup("wikipedia", indexTree));
        System.out.println("Looking up 'turing'");
        System.out.println("\t" + lookup("turing", indexTree));

    }

}

